<?php
  $links = array(
    'css' => 'lib/lightbox/css/lightbox.min.css',
    'js' => 'lib/lightbox/js/lightbox.min.js'
  );
?>
